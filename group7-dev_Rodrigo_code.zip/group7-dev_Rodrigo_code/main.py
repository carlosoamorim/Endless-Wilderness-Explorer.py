from interface import *


def main():
    while True:
        interface()  # Show the main interface

if __name__ == "__main__":
    main()

